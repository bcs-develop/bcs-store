# BCS STORE v1 prototype

This is a **source-level visual reskin**, not a validated installable MGU binary.

Changes: BCS logo app icon (140x140), BCS STORE title, navy/blue palette accents.
The existing `bcs_store` internal ID and update/dependency logic remain unchanged intentionally to avoid breaking integrations. The app may still show upstream branding elsewhere.

Existing Wi-Fi, touch, repository, update and app management logic was not removed. **Functionality is not yet verified on an MGU.**

License and attribution files are retained. This build is not an upstream-independent BCS application yet.

Build from `apps/bcs_store` with `node tools/build.js` for source package; a compatible SDK donor is required for an OAP binary.
