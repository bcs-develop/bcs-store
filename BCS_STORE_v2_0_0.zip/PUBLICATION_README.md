# BCS Store v2.0.0 — publication candidate

This archive contains BCS Store application source, interface/control files, original license notices, and a test installable package. It is **not** a production-ready GitHub Release. The 2.0.0 package was versioned from the bundled 1.0.1 implementation and includes a dual-feed registration attempt, not a fully tested self-update system.

- BCS Store feed: `bcs-develop/bcs-store:releases`
- Future BCS apps feed: `bcs-develop/bcs-mgu-apps:releases`
- Preserve upstream Robert Nisipeanu credits and supporting tool feeds.

Upload source files under the `apps/bcs_store/` folder to the BCS Store repository. Retain the included `LICENSE` and notices. The `release-candidate/` folder contains the installable app and catalog for **offline verification only**; do not publish them as live release assets before a backed-up BMW MGU test confirms source registration, download, installation, rollback and source persistence.

The full private Windows installer and its licensing/SSH resources are deliberately excluded.
