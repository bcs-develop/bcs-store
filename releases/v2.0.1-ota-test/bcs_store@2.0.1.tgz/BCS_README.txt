BCS STORE - VISUAL RESKIN v1.0 (based on robertn_store 0.9.16)

Included:
- Supplied BCS Store transparent PNG icon resized to original 140x140 launcher format
- BCS Store display title (English and Chinese)
- Updated neon-blue/dark-navy theme and BCS STORE screen headings
- Original internal package ID, version, updater interactions, pages, handlers and modules preserved

IMPORTANT: This is a visual-only adaptation of the supplied package, NOT a verified fully independent fork.
It has NOT been tested on a real BMW MGU, and may be overwritten by upstream updates.
The original robertn_store app ID is intentionally retained to avoid breaking integration.
Back up the existing app and head-unit data first; test on a bench head unit before vehicle deployment.
Use your existing compatible MGU app installer to import the TGZ package.

Licenses and original authorship remain in LICENSES.txt and package metadata.

BCS Store standalone app identity: bcs_store 1.0.0.
GPL upstream author notices retained.

BCS Store v2.0.1: Minimal UI revision, larger navigation and touch targets, refined dark theme, cleaner settings and detail layout.
