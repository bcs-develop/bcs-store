'use strict';
/**
 * The Store's screens laid out for a box under 700 px high (iDrive 7: the
 * page template's 1796 x 632, or the app area's 1790 x 638), at scale 1:
 * the same screens and element names as src/am_screens.js (App Manager 2's
 * iDrive 8 design), so src/store_ui.js gives both their values, but with a
 * one-row header (title, status, filters, online state), small margins,
 * two rows of larger tiles, list rows and buttons sized for the iDrive 7's text.
 *
 *   compact(w, h) -> { design: { w, h }, screens }
 *
 * Every element stays inside the box with room for the focus ring (8 px
 * out, 5 px wide).
 */

const M = 18;                 // the box's margin: the focus ring's room
const RAIL = 142;
const NAV_ITEMS = 'Store, cart\nInstalled, layers\nSettings, gear';
const TEXT = 'text';
const DIM = 'dim';
const AMBER = '#ffb020';
const BLUE = '#72b8ff';

const el = (name, gpu, x, y, w, h, opts, onTap) => Object.assign({ name, rtype: 'gpu', gpu, x: Math.round(x), y: Math.round(y),
    w: Math.round(w), h: Math.round(h), opts }, onTap ? { onTap } : {});
const text = (name, x, y, w, h, t, size, font, color, extra) => el(name, 'text', x, y, w, h,
    Object.assign({ text: t, size, font: font || 'label', align: 'left', color: color || TEXT }, extra || {}));
const button = (name, x, y, w, h, t, style, size, extra) => el(name, 'vbutton', x, y, w, h,
    Object.assign({ text: t, vicon: '', style: style || 'outline', size }, extra || {}), `event:${name}`);

function compact(W, H) {
    const X = M + RAIL + 16;          // the content's left edge
    const R = W - M;                  // its right edge
    const B = H - M;                  // its bottom
    const CW = R - X;
    const nav = (sel) => el('nav', 'sideNav', M, M, RAIL, H - 2 * M, { items: NAV_ITEMS, sel, labelSize: 22 });
    const screen = (name, sel, components) => ({ kind: 'gpu', name, theme: 'bcs_neon', bg: 'theme',
        components: [nav(sel)].concat(components) });
    // the header row: the title, then the status on its baseline (one right after the title moved right of a longer title)
    const HEAD = M + 64;
    const title = (t, x) => text('title', x === undefined ? X : x, M + 2, 640, 60, t, 44, 'bold');
    const status = (name, x, w, color) => text(name, x, M + 24, w, 30, '', 23, 'label', color || DIM);
    const after = (name, x, w, color) => text(name, x, M + 24, w, 30, '', 23, 'label', color || DIM, { after: 'title' });
    const back = () => el('back', 'vbutton', X, M, 64, 64, { text: '', vicon: 'back', style: 'round', color: '#f4f7fb' }, 'event:back');
    const BTN_H = 76;
    const GRID_Y = HEAD + 10;
    const grid = () => el('grid', 'appGrid', X - 8, GRID_Y, CW + 8, B - GRID_Y, { items: '', cols: 4, tileH: Math.floor((B - GRID_Y) / 2),
        iconK: 0.64, titleSize: 27, subSize: 20, empty: '' });
    const LIST = { rowH: 100, titleSize: 25, subSize: 19, ctlK: 0.82 };
    const list = (name, x, y, w, h, extra) => el(name, 'appList', x, y, w, h, Object.assign({ items: '' }, LIST, extra || {}));
    const label = (name, x, y, t) => text(name, x, y, 400, 26, t, 20, 'bold', DIM);

    const FILTER_W = 360;
    const ONLINE_W = 190;
    const filterX = R - ONLINE_W - 20 - FILTER_W;
    const store = screen('store', 0, [
        title('Store'),
        after('subtitle', X + 160, R - ONLINE_W - X - 200),
        el('online', 'chips', R - ONLINE_W, M + 8, ONLINE_W, 48, { items: '', align: 'right', signalMode: true }),
        el('filter', 'segmented', X + 12, HEAD + 4, 360, 52, { items: 'Apps,Tools', sel: 0 }),
        grid()
    ]);
    const usb = screen('usb', 2, [title('USB'), after('subtitle', X + 130, CW - 130), grid()]); // legacy hidden page

    const LIST_Y = HEAD + 38;
    const installed = screen('installed', 1, [
        title('Installed'),
        after('subtitle', X + 240, CW - 240 - 380),
        button('updateAll', R - 360, M, 360, 66, '', 'primary', 25, { vicon: 'arrowDown', color: BLUE }),
        label('appsTitle', X + 12, LIST_Y - 30, 'APPS'),
        label('toolsTitle', X + CW / 2 + 16, LIST_Y - 30, 'TOOLS'),
        list('apps', X, LIST_Y, CW / 2 - 12, B - LIST_Y, { empty: 'No apps installed' }),
        list('services', X + CW / 2 + 12, LIST_Y, CW / 2 - 12, B - LIST_Y,
            { empty: 'No tools installed', rowH: 110 })
    ]);

    // BCS simplified settings: repository and account controls remain in the backend,
    // but are not exposed on the customer-facing Settings screen.
    const leftW = Math.round(CW * 0.45);
    const rx = X + leftW + 24;
    const rw = R - rx;
    const SET_H = 72;
    const settings = screen('settings', 2, [
        title('Settings'),
        after('note', X + 230, CW - 230, AMBER),
        el('connPanel', 'rect', X, HEAD + 8, leftW, B - HEAD - 8, { color: 'panelTop', radius: 20 }),
        label('connLabel', X + 20, HEAD + 24, 'CONNECTIVITY'),
        list('access', X + 14, HEAD + 64, leftW - 28, LIST.rowH),
        label('systemLabel', X + 20, HEAD + 74 + LIST.rowH, 'SYSTEM'),
        text('unit', X + 20, HEAD + 120 + LIST.rowH, leftW - 40, 50, '', 25, 'bold'),
        text('versions', X + 20, HEAD + 175 + LIST.rowH, leftW - 40, 60, '', 21, 'label', DIM, { wrap: true }),
        button('checkNow', X + 16, B - SET_H - 14, (leftW - 44) / 2, SET_H, 'Check updates', 'outline', 24, { vicon: 'refresh' }),
        button('restart', X + 28 + (leftW - 44) / 2, B - SET_H - 14, (leftW - 44) / 2, SET_H, 'Restart', 'outline', 24, { vicon: 'power' }),
        el('sourcesPanel', 'rect', rx, HEAD + 8, rw, B - HEAD - 8, { color: 'panelTop', radius: 20 }),
        label('sourcesTitle', rx + 20, HEAD + 24, 'UPDATE SOURCES'),
        list('repos', rx + 14, HEAD + 70, rw - 28, B - HEAD - 170,
            { rowH: 94, titleSize: 22, subSize: 17, empty: 'No sources configured' }),
        button('addRepo', rx + 14, B - 86, rw - 28, 68, 'Add source', 'primary', 23, { vicon: 'plus' })
    ]);

    // a component's page: what it is on the left, the versions and the buttons in the panel on the right
    const PW = 470;
    const px = R - PW;
    const lw = px - X - 24;
    const ix = X + 224;
    const secondaryY = B - BTN_H - 14;
    const primaryY = secondaryY - 12 - 84;
    const app = screen('app', 0, [
        back(),
        el('icon', 'appIcon', X + 84, M, 120, 120, { vicon: '', colors: '#3a4352,#232a35' }),
        text('name', ix, M, lw - 224, 72, '', 63, 'bold'),
        text('author', ix, M + 76, lw - 224, 32, '', 27, 'label', DIM),
        el('facts', 'chips', ix, M + 114, lw - 224, 44, { items: '' }),
        text('desc', X, M + 176, lw, B - M - 176 - 84, '', 27, 'label', TEXT, { wrap: true }),
        text('problem', X, B - 76, lw, 76, '', 27, 'label', AMBER, { wrap: true }),
        el('panel', 'rect', px, M, PW, H - 2 * M, { color: 'panelTop', radius: 20 }),
        text('instLabel', px + 20, M + 16, 200, 28, '', 22, 'label', DIM),
        text('instValue', px + 20, M + 46, 200, 58, '', 46, 'num'),
        text('availLabel', px + 230, M + 16, 220, 28, '', 22, 'label', DIM),
        text('availValue', px + 230, M + 46, 220, 58, '', 46, 'num', BLUE),
        text('note1', px + 20, M + 118, PW - 40, 32, '', 25, 'label', DIM),
        text('note2', px + 20, M + 154, PW - 40, 32, '', 25, 'label', DIM),
        text('note3', px + 20, M + 190, PW - 40, 32, '', 25, 'label', AMBER),
        el('progress', 'progress', px + 20, primaryY - 104, PW - 40, 90, { label: '', right: '', sub: '', value: 0, percent: false,
            size: 24, hidden: true }),
        button('primary', px + 20, primaryY, PW - 40, 84, '', 'primary', 30, { vicon: 'arrowDown', color: BLUE }),
        button('secondary', px + 20, secondaryY, PW - 40, BTN_H, '', 'outline', 28, { vicon: 'trash' })
    ]);

    // the confirm sheet over the page
    const SW = Math.min(1200, CW);
    const SH = 380;
    const sx = X + (CW - SW) / 2;
    const sy = (H - SH) / 2;
    const BW = (SW - 100) / 2;
    const confirm = screen('confirm', 0, [
        el('sheet', 'sheet', sx, sy, SW, SH, { radius: 24 }),
        el('icon', 'appIcon', sx + 40, sy + 36, 110, 110, { vicon: '', colors: '#3a4352,#232a35' }),
        text('title', sx + 176, sy + 44, SW - 216, 50, '', 41, 'bold'),
        text('text', sx + 176, sy + 104, SW - 216, 32, '', 26, 'label', DIM),
        button('now', sx + 40, sy + SH - 126, BW, 90, '', 'primary', 31, { color: BLUE }),
        button('later', sx + 60 + BW, sy + SH - 126, BW, 90, 'Cancel', 'outline', 31),
        text('note', sx + 40, sy + SH - 30, SW - 80, 24, '', 21, 'label', DIM, { align: 'center' })
    ]);

    const QR_PW = 430;
    const qx = R - QR_PW;
    const sw = qx - ix - 24;
    const source = screen('source', 3, [
        back(),
        el('icon', 'appIcon', X + 84, M, 120, 120, { vicon: 'lock', kind: 'service', colors: '#3a4352,#232a35' }),
        text('name', ix, M, sw, 62, '', 53, 'bold'),
        text('state', ix, M + 66, sw, 32, '', 27, 'label', DIM),
        el('facts', 'chips', ix, M + 104, sw, 44, { items: [] }),
        text('desc', X, M + 166, qx - X - 24, B - BTN_H - 24 - M - 166, '', 26, 'label', AMBER, { wrap: true }),
        button('remove', X, B - BTN_H, 420, BTN_H, 'Remove', 'outline', 29, { vicon: 'trash' }),
        el('panel', 'rect', qx, M, QR_PW, H - 2 * M, { color: 'panelTop', radius: 20 }),
        text('appLabel', qx + 20, M + 14, QR_PW - 40, 34, '', 26, 'bold'),
        el('appQr', 'qr', qx + 30, M + 58, QR_PW - 60, QR_PW - 60, { text: '' }),
        text('appUrl', qx + 20, B - 40, QR_PW - 40, 26, '', 17, 'label', DIM)
    ]);

    const titleX = X + 84;
    const accounts = screen('accounts', 3, [
        back(),
        title('Accounts', titleX),
        after('status', titleX + 260, CW - 360),
        list('list', X, HEAD + 14, Math.min(1100, CW), B - BTN_H - 16 - HEAD - 14, { empty: 'None' }),
        button('signIn', X, B - BTN_H, 520, BTN_H, 'Sign in with GitHub', 'primary', 29, { vicon: 'plus', color: BLUE }),
        button('addToken', X + 544, B - BTN_H, 360, BTN_H, 'Add token', 'outline', 29, { vicon: 'plus' })
    ]);
    const pick = screen('pick', 3, [
        back(),
        // a repo's name takes what the status leaves
        text('title', titleX, M + 2, CW - 84 - 440, 60, '', 50, 'bold'),
        status('status', R - 420, 420),
        list('list', X, HEAD + 14, Math.min(1100, CW), B - BTN_H - 16 - HEAD - 14, { empty: '' }),
        button('signIn', X, B - BTN_H, 520, BTN_H, 'Sign in with GitHub', 'primary', 29, { vicon: 'plus', color: BLUE }),
        button('addToken', X + 544, B - BTN_H, 360, BTN_H, 'Add token', 'outline', 29, { vicon: 'plus' }),
        button('retry', X, B - BTN_H, 360, BTN_H, 'Try again', 'outline', 29, { vicon: 'refresh' })
    ]);
    const QR = Math.min(B - HEAD - 10, 520);
    const login = screen('login', 3, [
        back(),
        title('Sign in with GitHub', titleX),
        el('qr', 'qr', X, HEAD + 10, QR, QR, { text: '' }),
        text('code', X + QR + 40, HEAD + 36, CW - QR - 40, 94, '', 80, 'bold'),
        text('url', X + QR + 40, HEAD + 150, CW - QR - 40, 34, '', 27, 'label', DIM),
        text('status', X + QR + 40, HEAD + 200, CW - QR - 40, 34, '', 27, 'label', DIM),
        button('cancel', X + QR + 40, HEAD + 270, 360, BTN_H, 'Cancel', 'outline', 29)
    ]);
    const PQR = Math.min(B - M, 560);
    const phoneW = CW - PQR - 40;
    const phone = screen('phone', 3, [
        back(),
        title('Phone access', titleX),
        list('toggleRow', X, HEAD + 14, phoneW, LIST.rowH),
        text('url', X, HEAD + 124, phoneW, 130, '', 26, 'label', DIM, { wrap: true }),
        text('error', X, HEAD + 264, phoneW, 130, '', 26, 'label', AMBER, { wrap: true }),
        el('qr', 'qr', R - PQR, M, PQR, PQR, { text: '' })
    ]);
    // text typed on the drawn keyboard: the text box under the title, the keyboard below
    const FIELD_H = 64;
    const keysY = HEAD + 14 + FIELD_H + 16;
    const type = screen('type', 3, [
        back(),
        title('', titleX),
        el('field', 'field', X, HEAD + 14, CW, FIELD_H, { text: '', caret: true, focus: true, size: 30 }),
        el('keyboard', 'keyboard', X, keysY, CW, B - keysY, { shift: false })
    ]);
    // Wi-Fi: the networks on the left, the state and its buttons in the panel on the right
    const wbY = (k) => B - 14 - (3 - k) * BTN_H - (2 - k) * 12;      // the panel's k-th button (0, 1, 2)
    const wifi = screen('wifi', 3, [
        back(),
        title('Wi-Fi', titleX),
        after('subtitle', titleX + 170, px - titleX - 194),
        list('networks', X, HEAD + 14, px - X - 24, B - HEAD - 14, { empty: '' }),
        el('panel', 'rect', px, M, PW, H - 2 * M, { color: 'panelTop', radius: 20 }),
        el('icon', 'appIcon', px + 20, M + 20, 96, 96, { vicon: 'wifi', kind: 'service', colors: '#7a808a,#3a3f47' }),
        text('state', px + 132, M + 30, PW - 152, 36, '', 28, 'bold'),
        text('info', px + 132, M + 72, PW - 152, 30, '', 23, 'label', DIM),
        text('note', px + 20, M + 132, PW - 40, wbY(0) - 12 - M - 132, '', 23, 'label', AMBER, { wrap: true }),
        button('power', px + 20, wbY(0), PW - 40, BTN_H, '', 'outline', 28, { vicon: 'wifi' }),
        button('scan', px + 20, wbY(1), PW - 40, BTN_H, 'Scan', 'outline', 28, { vicon: 'refresh' }),
        button('prefer', px + 20, wbY(2), PW - 40, BTN_H, '', 'outline', 28, { vicon: 'route' })
    ]);
    const prefer = screen('prefer', 3, [
        back(),
        title('Preferred connection', titleX),
        status('status', R - 420, 420),
        list('list', X, HEAD + 14, Math.min(1100, CW), B - HEAD - 14, { empty: '' })
    ]);
    return { design: { w: W, h: H }, screens: [store, app, confirm, installed, usb, settings, source, accounts, pick, login, phone, type,
        wifi, prefer] };
}

module.exports = { compact };
